document.getElementsByTagName('html')[0].className += ' js';
